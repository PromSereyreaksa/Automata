from django import forms
from .models import DFA, NFA

# Common Tailwind CSS classes for form inputs to ensure consistent styling
text_input_classes = "w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"

class DFACreateForm(forms.ModelForm):
    """
    A form for creating a new Deterministic Finite Automaton (DFA).
    It handles the name and alphabet, which are the initial properties.
    States and transitions will be managed dynamically on the automaton's detail page.
    """
    class Meta:
        model = DFA
        fields = ['name', 'alphabet']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': text_input_classes,
                'placeholder': 'e.g., Even Number of A\'s'
            }),
            'alphabet': forms.TextInput(attrs={
                'class': text_input_classes,
                'placeholder': 'e.g., a,b'
            }),
        }
        help_texts = {
            'alphabet': 'Enter symbols separated by commas.',
        }

class NFACreateForm(forms.ModelForm):
    """
    A form for creating a new Nondeterministic Finite Automaton (NFA).
    Similar to the DFA form, it handles the initial setup.
    """
    class Meta:
        model = NFA
        fields = ['name', 'alphabet']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': text_input_classes,
                'placeholder': 'e.g., Ends with "ab"'
            }),
            'alphabet': forms.TextInput(attrs={
                'class': text_input_classes,
                'placeholder': 'e.g., a,b,ε'
            }),
        }
        help_texts = {
            'alphabet': 'Enter symbols separated by commas. Use "ε" for epsilon transitions.',
        }
