import json
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError


class Automaton(models.Model):
    """
    Abstract base model for all finite automata.
    It holds the common properties of DFAs and NFAs.
    """
    name = models.CharField(max_length=255)
    alphabet = models.CharField(
        max_length=255,
        help_text="Enter all symbols of the alphabet, separated by commas (e.g., a,b,c)",
    )
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    json_representation = models.JSONField(null=True, blank=True, help_text="JSON representation for graph visualization")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

    def get_alphabet_as_set(self):
        """Returns the alphabet as a set of strings."""
        return set(s.strip() for s in self.alphabet.split(',') if s.strip())

    def update_json_representation(self):
        """
        Updates the json_representation field with the current state of the automaton
        for visualization with Cytoscape.js.
        """
        nodes = []
        edges = []

        for state in self.states.all():
            nodes.append({
                'data': {
                    'id': state.name,
                    'name': state.name,
                    'pk': state.pk,  # Add primary key for AJAX operations
                    'is_start': state.is_start,
                    'is_final': state.is_final,
                }
            })

        for transition in self.transitions.all():
            edges.append({
                'data': {
                    'source': transition.from_state.name,
                    'target': transition.to_state.name,
                    'label': transition.symbol,
                    'pk': transition.pk,  # Add primary key for AJAX operations
                }
            })

        self.json_representation = {'nodes': nodes, 'edges': edges}
        self.save()

    def __str__(self):
        return self.name


class State(models.Model):
    """Represents a single state in an automaton."""
    automaton = models.ForeignKey('Automaton', related_name='states', on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    is_start = models.BooleanField(default=False)
    is_final = models.BooleanField(default=False)

    class Meta:
        abstract = True
        unique_together = ('automaton', 'name')

    def __str__(self):
        return f"{self.name} ({'start, ' if self.is_start else ''}{'final' if self.is_final else ''})"


class Transition(models.Model):
    """Represents a transition between two states on a given symbol."""
    automaton = models.ForeignKey('Automaton', related_name='transitions', on_delete=models.CASCADE)
    from_state = models.ForeignKey('State', related_name='from_transitions', on_delete=models.CASCADE)
    to_state = models.ForeignKey('State', related_name='to_transitions', on_delete=models.CASCADE)
    symbol = models.CharField(max_length=1)

    class Meta:
        abstract = True

    def clean(self):
        # Ensure the symbol is in the automaton's alphabet
        if self.symbol not in self.automaton.get_alphabet_as_set():
            raise ValidationError(f"Symbol '{self.symbol}' is not in the automaton's alphabet.")

    def __str__(self):
        return f"({self.from_state.name}) --{self.symbol}--> ({self.to_state.name})"


class DFAState(State):
    automaton = models.ForeignKey('DFA', related_name='states', on_delete=models.CASCADE)


class DFATransition(Transition):
    automaton = models.ForeignKey('DFA', related_name='transitions', on_delete=models.CASCADE)
    from_state = models.ForeignKey(DFAState, related_name='from_transitions', on_delete=models.CASCADE)
    to_state = models.ForeignKey(DFAState, related_name='to_transitions', on_delete=models.CASCADE)


class NFAState(State):
    automaton = models.ForeignKey('NFA', related_name='states', on_delete=models.CASCADE)


class NFATransition(Transition):
    automaton = models.ForeignKey('NFA', related_name='transitions', on_delete=models.CASCADE)
    from_state = models.ForeignKey(NFAState, related_name='from_transitions', on_delete=models.CASCADE)
    to_state = models.ForeignKey(NFAState, related_name='to_transitions', on_delete=models.CASCADE)


class DFA(Automaton):
    """Represents a Deterministic Finite Automaton."""

    def is_valid(self):
        """
        Checks if the DFA is valid:
        1. Exactly one start state.
        2. For each state and each symbol in the alphabet, there is exactly one transition.
        """
        start_states_count = self.states.filter(is_start=True).count()
        if start_states_count != 1:
            return False, "A DFA must have exactly one start state."

        alphabet = self.get_alphabet_as_set()
        for state in self.states.all():
            for symbol in alphabet:
                if self.transitions.filter(from_state=state, symbol=symbol).count() != 1:
                    return False, f"State '{state.name}' must have exactly one transition for symbol '{symbol}'."
        return True, "DFA is valid."

    def simulate(self, input_string):
        """Simulates the DFA on a given input string."""
        if not self.states.filter(is_start=True).exists():
            return False, "No start state defined.", []

        current_state = self.states.get(is_start=True)
        path = [current_state.name]

        for symbol in input_string:
            if symbol not in self.get_alphabet_as_set():
                return False, f"Input symbol '{symbol}' is not in the alphabet.", path
            try:
                transition = self.transitions.get(from_state=current_state, symbol=symbol)
                current_state = transition.to_state
                path.append(current_state.name)
            except DFATransition.DoesNotExist:
                return False, f"No transition found from state '{current_state.name}' on symbol '{symbol}'.", path

        return current_state.is_final, "Simulation completed.", path

    def minimize(self):
        """
        Minimizes the DFA.
        (Implementation of minimization algorithm needed)
        """
        # Placeholder for DFA minimization logic
        pass


class NFA(Automaton):
    """Represents a Nondeterministic Finite Automaton."""

    def is_dfa(self):
        """
        Checks if the NFA is also a DFA.
        1. No epsilon transitions (assuming '' or None for epsilon).
        2. For each state and symbol, there is at most one transition.
        """
        alphabet = self.get_alphabet_as_set()
        if '' in alphabet or 'ε' in alphabet: # Check for epsilon transitions
             return False, "NFA has epsilon transitions."

        for state in self.states.all():
            for symbol in alphabet:
                if self.transitions.filter(from_state=state, symbol=symbol).count() > 1:
                    return False, f"State '{state.name}' has multiple transitions for symbol '{symbol}'."
        return True, "NFA is deterministic."

    def simulate(self, input_string):
        """Simulates the NFA on a given input string."""
        
        def epsilon_closure(states):
            """Calculates the epsilon closure for a set of states."""
            closure = set(states)
            stack = list(states)
            while stack:
                state = stack.pop()
                # Assuming epsilon is represented by an empty string ''
                epsilon_transitions = self.transitions.filter(from_state=state, symbol='')
                for trans in epsilon_transitions:
                    if trans.to_state not in closure:
                        closure.add(trans.to_state)
                        stack.append(trans.to_state)
            return closure

        if not self.states.filter(is_start=True).exists():
            return False, "No start state defined.", []

        start_state = self.states.get(is_start=True)
        current_states = epsilon_closure({start_state})
        path = [start_state.name]

        for symbol in input_string:
            if symbol not in self.get_alphabet_as_set() and symbol != '':
                return False, f"Input symbol '{symbol}' is not in the alphabet.", path

            next_states = set()
            for state in current_states:
                transitions = self.transitions.filter(from_state=state, symbol=symbol)
                for trans in transitions:
                    next_states.add(trans.to_state)
            
            if not next_states:
                return False, "Simulation stuck. No transition found.", path

            current_states = epsilon_closure(next_states)
            if current_states:
                path.append(list(current_states)[0].name)  # Add one representative state to path

        # Check if any of the final states is in the set of current states
        for state in current_states:
            if state.is_final:
                return True, "String accepted.", path
        
        return False, "String rejected.", path

    def to_dfa(self):
        """
        Converts the NFA to an equivalent DFA.
        (Implementation of subset construction algorithm needed)
        """
        # Placeholder for NFA to DFA conversion logic
        pass
